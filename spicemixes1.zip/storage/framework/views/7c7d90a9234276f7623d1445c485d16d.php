<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Aleid\Documents\Web Design New\laravel-svelte-inertia\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>